import cv2
import os
import json
import numpy as np

# Load labels dynamically (if available)
labels_file = "labels.json"
if os.path.exists(labels_file):
    with open(labels_file, "r") as file:
        labels = json.load(file)
else:
    labels = {}  # Default empty label dictionary

# Ensure dataset directory exists
if not os.path.exists("data"):
    os.makedirs("data")

# Function to save images in the format "user.id.NUM.jpg"
def generate_dataset(img, id, img_id):
    filename = f"data/user.{id}.{img_id}.jpg"
    cv2.imwrite(filename, img)

# Function to draw face detection boundary
def draw_boundary(img, classifier, scaleFactor, minNeighbors, color, clf=None):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    features = classifier.detectMultiScale(gray_img, scaleFactor, minNeighbors)
    coords = []
    
    for (x, y, w, h) in features:
        cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
        if clf:
            roi_gray = gray_img[y:y + h, x:x + w]
            id, confidence = clf.predict(roi_gray)

            label = labels.get(str(id), "Unknown")
            confidence_text = f"{label} ({round(confidence, 2)})"

            if confidence < 70:
                cv2.putText(img, confidence_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2, cv2.LINE_AA)
            else:
                cv2.putText(img, "Unknown", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2, cv2.LINE_AA)

        coords.append((x, y, w, h))
    
    return coords, img

# Function to recognize faces
def recognize_face(img, clf):
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    faces = faceCascade.detectMultiScale(gray_img, scaleFactor=1.1, minNeighbors=10)
    
    for (x, y, w, h) in faces:
        roi_gray = gray_img[y:y + h, x:x + w]
        id, confidence = clf.predict(roi_gray)
        label = labels.get(str(id), "Unknown")

        if confidence < 70:
            cv2.putText(img, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2, cv2.LINE_AA)
        else:
            cv2.putText(img, "Unknown", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2, cv2.LINE_AA)
    
    return img

# Function to detect faces and eyes
def detect(img, faceCascade, eyeCascade, img_id, clf):
    color = {"blue": (255, 0, 0), "red": (0, 0, 255), "green": (0, 255, 0)}
    coords, img = draw_boundary(img, faceCascade, 1.1, 10, color['blue'], clf)
    
    if coords:
        for (x, y, w, h) in coords:
            roi_img = img[y:y + h, x:x + w]
            generate_dataset(roi_img, id=1, img_id=img_id)  # Save detected face
            img = recognize_face(img, clf)
            detect_blink(img, eyeCascade, (x, y, w, h))
    
    return img

# Function to detect blinking
def detect_blink(img, eyeCascade, face_coords):
    x, y, w, h = face_coords
    roi_gray = cv2.cvtColor(img[y:y + h, x:x + w], cv2.COLOR_BGR2GRAY)
    eyes = eyeCascade.detectMultiScale(roi_gray, scaleFactor=1.1, minNeighbors=5)
    
    if len(eyes) < 2:
        cv2.putText(img, "Blink Detected", (x, y + h + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2, cv2.LINE_AA)
    
    return img

# Load classifiers
faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eyeCascade = cv2.CascadeClassifier('haarcascade_eye.xml')

# Load the recognizer and trained model
clf = cv2.face.LBPHFaceRecognizer_create()
clf.read("classifier.xml")

# Start video capture
video_capture = cv2.VideoCapture(0)
img_id = 0

while True:
    _, img = video_capture.read()
    img = detect(img, faceCascade, eyeCascade, img_id, clf)
    cv2.imshow("Face Detection", img)
    img_id += 1
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()
