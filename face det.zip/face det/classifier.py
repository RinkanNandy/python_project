import numpy as np
from PIL import Image, ImageEnhance
import os, cv2, random

def augment_image(img):
    """Applies random augmentation to an image."""
    if random.random() > 0.5:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if random.random() > 0.5:
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(random.uniform(0.7, 1.3))
    return img

def train_classifier(data_dir):
    """Trains a face recognition classifier using LBPH algorithm."""
    image_paths = [os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.lower().endswith(('png', 'jpg', 'jpeg'))]
    
    if not image_paths:
        print("No images found in dataset directory.")
        return
    
    faces, ids = [], []
    
    for image_path in image_paths:
        try:
            img = Image.open(image_path).convert('L')
            img = augment_image(img)
            image_np = np.array(img, 'uint8')
            id = int(os.path.split(image_path)[1].split(".")[1])
            faces.append(image_np)
            ids.append(id)
        except Exception as e:
            print(f"Error processing {image_path}: {e}")
    
    if len(set(ids)) < 2:
        print("Not enough unique faces to train the classifier. Add more images.")
        return
    
    ids = np.array(ids)
    
    clf = cv2.face.LBPHFaceRecognizer_create()
    clf.train(faces, ids)
    clf.write("classifier.xml")
    
    print("Training completed successfully, classifier saved as 'classifier.xml'.")

if __name__ == "__main__":
    train_classifier("data")
